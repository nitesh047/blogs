 <nav class="navbar navbar-expand-lg" id="nav">
  <div class="container-fluid">
    <a class="navbar-brand" style="margin-left: 20px;font-size:35px;color: white;" href="../Blogs.php">Tech Tutor</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" style="justify-content:flex-end;margin-right: 20px;" id="navbarNav">
      <ul class="navbar-nav" id="navUL">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="https://www.linkedin.com/in/nitesh-saini-80893b1a0/?originalSubdomain=in" target="_blank"
          ><span style="font-size: 25px;"><i class="bi bi-linkedin"></i></span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="https://twitter.com/niteshs98269013?t=GdqgPRpPRchXwJWSHLgxmA&s=08" target="_blank"><span style="font-size: 25px;"><i class="bi bi-twitter"></i></span> </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="https://www.instagram.com/nit.esh47/" target="_blank"><span style="font-size: 25px;"><i class="bi bi-instagram"></i></span> </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="https://www.facebook.com/people/Nitesh-Saini/100037318390429/" target="_blank"><span style="font-size: 25px;"><i class="bi bi-facebook"></i></span> </a>
        </li>
          <li class="nav-item">
          <a class="nav-link" href="https://github.com/nitesh047" target="_blank"><span style="font-size: 25px;"><i class="bi bi-github"></i></span> </a>
        </li>
      </ul>
    </div>
  </div>
</nav>