<br><Br>
       <hr style="border: 1px solid">
    <br>
    <center>
        <div class="container">
            <div class="row" style="display: flex; justify-content: center;">
                <div class="col-md-1">
           <a class="nav-link" href="/personalBlog/Components/Contact.html"><span style="font-size: 25px;"><i class="bi bi-share-fill"></i></span> </a>
</div>
                <div class="col-md-1">

                    <a class="nav-link active" aria-current="page" href="https://www.linkedin.com/in/nitesh-saini-80893b1a0/?originalSubdomain=in" target="_blank"><span style="font-size: 25px;"><i class="bi bi-linkedin"></i></span></a>
                </div>
                <div class="col-md-1">
                    <a class="nav-link" href="https://twitter.com/niteshs98269013?t=GdqgPRpPRchXwJWSHLgxmA&s=08" target="_blank"><span style="font-size: 28px;"><i class="bi bi-twitter"></i></span> </a>
                </div>
 <div class="col-md-1">
     <a class="nav-link" href="https://www.instagram.com/nit.esh47/" target="_blank"><span style="font-size: 27px;"><i class="bi bi-instagram"></i></span> </a>
 </div>
       
        
       
        
       <div class="col-md-1">
           <a class="nav-link" href="https://www.facebook.com/people/Nitesh-Saini/100037318390429/" target="_blank"><span style="font-size: 27px;"><i class="bi bi-facebook"></i></span> </a>
       </div>
        
       <div class="col-md-1">
           <a class="nav-link" href="https://github.com/nitesh047" target="_blank"><span style="font-size: 27px;"><i class="bi bi-github"></i></span> </a>
</div>

          
       
            </div>
        </div>
    </center>
    <br><Br>