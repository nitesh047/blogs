<nav class="navbar  navbar-expand-lg" id="nav">
  <div class="container-fluid">
    <a class="navbar-brand" style="margin-left: 20px;font-size:35px;color: white;" href="./index.php">Tech Tutor</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" style="justify-content:flex-end;margin-right: 20px;" id="navbarNav">
      <ul class="navbar-nav" id="navUL">
        <li class="nav-item">
          <a class="nav-link " aria-current="page" href="./Blogs.php">Blogs</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./About.php">About </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./Contact.php">Contact </a>
        </li>
         
      </ul>
    </div>
  </div>
</nav>